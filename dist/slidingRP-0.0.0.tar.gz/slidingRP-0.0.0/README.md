# slidingRefractory
Code to perform a new test of whether neurons have contaminated refractory periods, with a sliding window


## Python

### Installation
```commandline
pip install slidingRP
```

### Minimal working example

```python
from pathlib import Path
import numpy as np
import pandas as pd

import slidingRP

TEST_DATA_PATH = Path(slidingRP.__file__).parent.parent.joinpath("test-data", "integration")

params = {'sampleRate': 30000, 'binSizeCorr': 1 / 30000}
spikes = pd.read_parquet(TEST_DATA_PATH.joinpath('spikes.pqt'))
table = slidingRP.slidingRP_all(spikes.times, spikes.clusters, **params)

assert np.allclose(pd.read_parquet(TEST_DATA_PATH.joinpath("rp_table.pqt")), pd.DataFrame(table), equal_nan=True)
```

### Contribute
#### Run unit tests
```commandline
 pytest python/test_*
```

#### Upload package
```commandline
rm -fR dist
rm -fR build
python setup.py sdist bdist_wheel
twine upload dist/*
```
